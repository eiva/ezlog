# (E)a(z)y (log)ging

Wrappers to make eazy logging of functions and members calls.
Allow to track parameters, exceptions and performance of functions.